package com.floatrec.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()

        status = TextView(this).apply {
            textSize = 16f
            text = "Tap Start. You will be asked for camera, microphone and 'Display over other apps' permission."
            setPadding(0, 0, 0, pad)
        }
        val start = Button(this).apply {
            text = "Start floating recorder"
            setOnClickListener { begin() }
        }
        val stop = Button(this).apply {
            text = "Stop floating recorder"
            setOnClickListener {
                startService(Intent(this@MainActivity, FloatService::class.java).setAction(FloatService.ACTION_STOP))
            }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            addView(status)
            addView(start)
            addView(stop)
        })
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun begin() {
        if (!granted(Manifest.permission.CAMERA) || !granted(Manifest.permission.RECORD_AUDIO)) {
            val list = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
                list.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            requestPermissions(list.toTypedArray(), 1)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Allow 'Display over other apps' for FloatRec, then come back and tap Start again."
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        startForegroundService(Intent(this, FloatService::class.java))
        moveTaskToBack(true)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (granted(Manifest.permission.CAMERA) && granted(Manifest.permission.RECORD_AUDIO)) {
            begin()
        } else {
            status.text = "Camera and microphone permission are required."
        }
    }
}
