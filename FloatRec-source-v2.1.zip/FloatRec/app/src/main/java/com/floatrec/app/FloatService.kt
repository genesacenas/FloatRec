package com.floatrec.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

@Suppress("DEPRECATION")
class FloatService : Service() {

    companion object {
        const val ACTION_STOP = "com.floatrec.app.STOP"
        private const val CHANNEL = "floatrec"
        private const val PREVIEW_W = 1280
        private const val PREVIEW_H = 720
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var recBtn: TextView
    private lateinit var flipBtn: TextView
    private lateinit var qualityBtn: TextView
    private lateinit var prevBtn: TextView
    private lateinit var timerView: TextView
    private lateinit var previewView: TextureView
    private var previewSurface: Surface? = null
    private var overlayAdded = false

    private var useFront = false
    private var use1080 = true
    private var previewOn = false
    private var recording = false
    private var started = false
    private var recStart = 0L

    private var camera: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var recorder: MediaRecorder? = null
    private var pendingUri: android.net.Uri? = null
    private var pfd: ParcelFileDescriptor? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null

    private val tick = object : Runnable {
        override fun run() {
            if (!recording) return
            val s = ((SystemClock.elapsedRealtime() - recStart) / 1000).toInt()
            timerView.text = if (s >= 3600)
                String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
            else
                String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
            main.postDelayed(this, 500)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (!overlayAdded) buildOverlay()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        finishRecording()
        if (overlayAdded) {
            try { wm.removeView(root) } catch (_: Exception) {}
            overlayAdded = false
        }
        super.onDestroy()
    }

    private fun shutdown() {
        finishRecording()
        stopSelf()
    }

    // ---------- notification ----------

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Floating recorder", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, FloatService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Floating recorder is on")
            .setContentText("Tap the floating button to record")
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "Close", stopPi
                ).build()
            )
            .build()
        startForeground(
            1, n,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )
    }

    // ---------- floating widget ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun circle(color: Int, label: String, sizeDp: Int, textSp: Float): TextView =
        TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = textSp
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
            }
            layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)).apply {
                setMargins(dp(2), dp(2), dp(2), dp(2))
            }
        }

    private fun setBg(v: TextView, color: Int) = (v.background as GradientDrawable).setColor(color)

    private fun buildOverlay() {
        wm = getSystemService(WindowManager::class.java)

        // live preview (hidden until PREV is switched on)
        previewView = TextureView(this).apply {
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(dp(90), dp(160)).apply {
                setMargins(0, 0, 0, dp(4))
            }
            surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                    st.setDefaultBufferSize(PREVIEW_W, PREVIEW_H)
                    previewSurface = Surface(st)
                }
                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
                override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                    previewSurface?.release()
                    previewSurface = null
                    return true
                }
                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
            }
        }

        // recording timer pill
        timerView = TextView(this).apply {
            text = "00:00"
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(2), dp(10), dp(2))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(0xCCE53935.toInt())
            }
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, dp(2), 0, dp(2)) }
        }

        recBtn = circle(0xFF37474F.toInt(), "REC", 64, 14f)
        flipBtn = circle(0xFF455A64.toInt(), "BACK", 36, 9f)
        qualityBtn = circle(0xFF455A64.toInt(), "1080p", 36, 9f)
        prevBtn = circle(0xFF455A64.toInt(), "PREV", 36, 9f)
        val closeBtn = circle(0xFF263238.toInt(), "\u2715", 36, 13f)

        flipBtn.setOnClickListener {
            if (!recording) { useFront = !useFront; refreshUi() }
        }
        qualityBtn.setOnClickListener {
            if (!recording) { use1080 = !use1080; refreshUi() }
        }
        prevBtn.setOnClickListener {
            if (!recording) {
                previewOn = !previewOn
                previewView.visibility = if (previewOn) View.VISIBLE else View.GONE
                refreshUi()
                try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
            }
        }
        closeBtn.setOnClickListener { shutdown() }

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(120)
        }

        // drag by the REC button; a tap (no movement) toggles recording
        recBtn.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0; var startY = 0
            var touchX = 0f; var touchY = 0f
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = lp.x; startY = lp.y
                        touchX = e.rawX; touchY = e.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - touchX).toInt()
                        val dy = (e.rawY - touchY).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        if (moved) {
                            lp.x = startX + dx
                            lp.y = startY + dy
                            wm.updateViewLayout(root, lp)
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) toggle()
                }
                return true
            }
        })

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(flipBtn)
            addView(qualityBtn)
            addView(prevBtn)
            addView(closeBtn)
        }

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(previewView)
            addView(timerView)
            addView(recBtn)
            addView(row)
        }
        wm.addView(root, lp)
        overlayAdded = true
        refreshUi()
    }

    private fun refreshUi() {
        if (!overlayAdded) return
        recBtn.text = if (recording) "STOP" else "REC"
        setBg(recBtn, if (recording) 0xFFE53935.toInt() else 0xFF37474F.toInt())
        flipBtn.text = if (useFront) "FRONT" else "BACK"
        qualityBtn.text = if (use1080) "1080p" else "720p"
        setBg(prevBtn, if (previewOn) 0xFF00897B.toInt() else 0xFF455A64.toInt())
        val a = if (recording) 0.4f else 1f
        flipBtn.alpha = a
        qualityBtn.alpha = a
        prevBtn.alpha = a
        timerView.visibility = if (recording) View.VISIBLE else View.GONE
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun toggle() {
        if (recording) finishRecording() else startRecording()
    }

    // ---------- recording ----------

    @SuppressLint("MissingPermission")
    private fun startRecording() {
        if (recorder != null) return
        try {
            val cm = getSystemService(CameraManager::class.java)
            val want = if (useFront) CameraCharacteristics.LENS_FACING_FRONT
                       else CameraCharacteristics.LENS_FACING_BACK
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == want
            }
            if (id == null) {
                toast("Camera not found")
                return
            }
            val chars = cm.getCameraCharacteristics(id)
            val sensor = chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90

            // pick resolution: 1080p if wanted and supported, otherwise 720p
            var w = 1280; var h = 720; var bitrate = 8_000_000
            if (use1080) {
                val sizes = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                    ?.getOutputSizes(MediaRecorder::class.java)
                if (sizes != null && sizes.any { it.width == 1920 && it.height == 1080 }) {
                    w = 1920; h = 1080; bitrate = 16_000_000
                } else {
                    toast("1080p not supported on this camera, using 720p")
                }
            }

            val name = "FloatRec_" +
                SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/FloatRec")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            if (uri == null) {
                toast("Cannot create video file")
                return
            }
            pendingUri = uri
            pfd = contentResolver.openFileDescriptor(uri, "w")

            val mr = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            mr.setAudioSource(MediaRecorder.AudioSource.MIC)
            mr.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setOutputFile(pfd!!.fileDescriptor)
            mr.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            mr.setVideoSize(w, h)
            mr.setVideoFrameRate(30)
            mr.setVideoEncodingBitRate(bitrate)
            mr.setAudioEncodingBitRate(128_000)
            mr.setAudioSamplingRate(44_100)
            mr.setOrientationHint(sensor)   // upright video when the phone is held in portrait
            mr.prepare()
            recorder = mr
            started = false

            thread = HandlerThread("floatrec-cam").also { it.start() }
            handler = Handler(thread!!.looper)

            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(cam: CameraDevice) {
                    camera = cam
                    try {
                        val surfaces = mutableListOf(recorder!!.surface)
                        val ps = previewSurface
                        if (previewOn && ps != null) surfaces.add(ps)

                        val req = cam.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                            .apply { surfaces.forEach { addTarget(it) } }
                        cam.createCaptureSession(surfaces,
                            object : CameraCaptureSession.StateCallback() {
                                override fun onConfigured(s: CameraCaptureSession) {
                                    session = s
                                    try {
                                        s.setRepeatingRequest(req.build(), null, handler)
                                        recorder?.start()
                                        started = true
                                        main.post {
                                            recStart = SystemClock.elapsedRealtime()
                                            recording = true
                                            timerView.text = "00:00"
                                            refreshUi()
                                            main.post(tick)
                                        }
                                    } catch (e: Exception) {
                                        main.post { toast("Start failed: ${e.message}"); finishRecording() }
                                    }
                                }
                                override fun onConfigureFailed(s: CameraCaptureSession) {
                                    main.post { toast("Camera setup failed"); finishRecording() }
                                }
                            }, handler)
                    } catch (e: Exception) {
                        main.post { toast("Camera error: ${e.message}"); finishRecording() }
                    }
                }
                override fun onDisconnected(cam: CameraDevice) {
                    main.post { finishRecording() }
                }
                override fun onError(cam: CameraDevice, error: Int) {
                    main.post { toast("Camera error $error"); finishRecording() }
                }
            }, handler)
        } catch (e: Exception) {
            toast("Start failed: ${e.message}")
            finishRecording()
        }
    }

    /** Stops recording (if any), saves the video, releases the camera. Call on the main thread. */
    private fun finishRecording() {
        main.removeCallbacks(tick)
        val mr = recorder
        var ok = started
        if (mr != null) {
            recorder = null
            try { session?.stopRepeating() } catch (_: Exception) {}
            if (started) {
                try { mr.stop() } catch (_: Exception) { ok = false }  // fails if < ~1 s recorded
            } else ok = false
            try { mr.release() } catch (_: Exception) {}
        }
        started = false
        try { session?.close() } catch (_: Exception) {}
        try { camera?.close() } catch (_: Exception) {}
        session = null
        camera = null
        try { pfd?.close() } catch (_: Exception) {}
        pfd = null

        pendingUri?.let { u ->
            if (ok) {
                val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                contentResolver.update(u, v, null, null)
                toast("Saved to Movies/FloatRec")
            } else {
                contentResolver.delete(u, null, null)
            }
        }
        pendingUri = null

        thread?.quitSafely()
        thread = null
        handler = null
        recording = false
        refreshUi()
    }
}
